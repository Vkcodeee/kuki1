

from SystemInfo import *

print(SystemInfo().get_info_text())
